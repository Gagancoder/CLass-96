import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TextInput,
  TouchableOpacity,
  Alert,
  KeyboardAvoidingView,
} from 'react-native';
import { createAppContainer, createSwitchNavigator } from 'react-navigation';
import { createBottomTabNavigator } from 'react-navigation-tabs';
// You can import from local files
import LoginScreen from './LoginScreen';
import Movie from './Movie';
import WeatherScreen from './Weather';
import Games from './Games';
import Home from './Home';
import QRScanner from './QRScanner';

// or any pure javascript modules available in npm
//import { Card } from 'react-native-paper';

export default class App extends React.Component {
  constructor() {
    super();
    this.state = {
      emailId: '',
      password: '',
    };
  }

  
  render() {
    return <AppContainer />;
  }
}

const TabNavigator = createBottomTabNavigator(
  {
    Home: Home,
    Movie: { screen: Movie },
    Games: { screen: Games },
    Weather: { screen: WeatherScreen },
    QRScanner: { screen: QRScanner },
  },
  {
    defaultNavigationOptions: ({ navigation }) => ({
      tabBarIcon: (
        source = {
          uri:
            'https://cdn3.iconfinder.com/data/icons/ballicons-reloaded-free/512/icon-70-512.png',
        }
      ) => {
        const routeName = navigation.state.routeName;
        if (routeName === 'Movie') {
          return (
            <Image
              style={{ width: 40, height: 30 }}
              source={{
                uri:
                  'https://www.pinclipart.com/picdir/big/388-3882676_trailer-01-transparent-background-film-icon-clipart.png',
              }}
            />
          );
        } else if (routeName === 'News') {
          return (
            <Image
              style={{ width: 40, height: 30 }}
              source={{
                uri:
                  'https://cdn3.iconfinder.com/data/icons/ballicons-reloaded-free/512/icon-70-512.png',
              }}
            />
          );
        } else if (routeName === 'Games') {
          return (
            <Image
              style={{ width: 40, height: 30 }}
              source={{
                uri:
                  'https://www.pinclipart.com/picdir/big/285-2859043_game-icon-images-usseek-com-game-controller-vector.png',
              }}
            />
          );
        } else if (routeName === 'Home') {
          return (
            <Image
              style={{ width: 40, height: 15 }}
              source={{
                uri: 'https://mnpthesolution.com/assets/img/logo.png',
              }}
            />
          );
        } else if (routeName === 'QRScanner') {
          return (
            <Image
              style={{ width: 40, height: 33 }}
              source={{
                uri:
                  'https://www.nicepng.com/png/detail/32-327357_scan-qr-code-qr-scan-icon-png.png',
              }}
            />
          );
        } else if (routeName === 'Weather') {
          return (
            <Image
              style={{ width: 40, height: 33, borderRadius: 10 }}
              source={{
                uri:
                  'https://i.pinimg.com/originals/06/c4/f7/06c4f70ec5931e2342e703e8a3f0a253.png',
              }}
            />
          );
        }
      },
    }),
  }
);
const switchNavigator = createSwitchNavigator({
  LoginScreen: { screen: LoginScreen },
  TabNavigator: { screen: TabNavigator },
});
const AppContainer = createAppContainer(switchNavigator);
