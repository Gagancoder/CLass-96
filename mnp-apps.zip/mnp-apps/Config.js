
export const firebaseConfig = {
    apiKey: "AIzaSyBgKDP9cqkmZYhZt0uNf_quhgA-V3UISWE",
    authDomain: "pen-warrior-s.firebaseapp.com",
    databaseURL: "https://pen-warrior-s-default-rtdb.firebaseio.com",
    projectId: "pen-warrior-s",
    storageBucket: "pen-warrior-s.appspot.com",
    messagingSenderId: "915676645975",
    appId: "1:915676645975:web:ba834da27a09828d177112"
  };
