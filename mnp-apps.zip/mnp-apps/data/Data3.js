import React from 'react';
import {View, Text,TouchableOpacity,StyleSheet} from 'react-native';


export const dummyData3 =

        [{

                 url: 'https://newretrowave.com/wp-content/uploads/2019/09/kitchen.jpg',
                
                id: 1,
              

        },
        {
                 url: 'https://i.pinimg.com/originals/6e/de/64/6ede64494d034893b62341b540688077.jpg',
               
                id: 2
        },
        {
                url: 'https://images-na.ssl-images-amazon.com/images/I/71lB6A8WIQL._AC_SL1326_.jpg',
               
                id: 3
        },
              {
                url: 'http://posterposse.com/wp-content/uploads/2017/06/main-1024x637.jpeg',
               
                id: 4
        }
              
              
              ]



              const styles = StyleSheet.create({
text1:{
  color:'#D4035E',
  alignItem:'top',
  fontSize:20,
  justifyContent:'top',
  marginBottom:0,
 marginLeft:10,
 marginRight:0

},
buttons: {
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderRadius: 15,
    margin: 10,
    width: 200,
    height: 50,
  },
  imageIcon: {
    width: 260,
    height: 240,
    marginLeft: 55,
  }
})


