import React from 'react';
import {View, Text,TouchableOpacity,StyleSheet} from 'react-native';


export const dummyData2 =

        [{

                 url: 'https://movieposters2.com/images/1394504-b.jpg',
                
                id: 1,
              

        },
        {
                 url: 'https://movieposters2.com/images/1631097-b.jpg',
               
                id: 2
        },
        {
                url: 'https://mypostercollection.com/wp-content/uploads/2020/01/Big-Hero-6-Poster-2.jpg',
               
                id: 3
        },
              {
                url: 'https://i.pinimg.com/originals/0d/ee/cf/0deecf965f167dfb77ea2c3f93a525d0.jpg',
               
                id: 4
        }
              
              
              ]



              const styles = StyleSheet.create({
text1:{
  color:'#D4035E',
  alignItem:'top',
  fontSize:20,
  justifyContent:'top',
  marginBottom:0,
 marginLeft:10,
 marginRight:0

},
buttons: {
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderRadius: 15,
    margin: 10,
    width: 200,
    height: 50,
  },
  imageIcon: {
    width: 260,
    height: 240,
    marginLeft: 55,
  }
})


