import React from 'react';
import {View, Text,TouchableOpacity,StyleSheet} from 'react-native';


export const dummyData1 =

        [{

                 url: 'https://i.etsystatic.com/27817007/r/il/c815c7/3004388421/il_300x300.3004388421_f94w.jpg',
                
                id: 1,
              

        },
        {
                 url: 'https://compass-ssl.xbox.com/assets/a7/74/a77438db-e4f8-4d30-92b4-5b26f246219f.jpg?n=Minecraft_Sneaky-Slider-1084_Aquatic_1600x675.jpg',
               
                id: 2
        },
        {
                url: 'https://www.festivalsherpa.com/wp-content/uploads/2021/03/minecraft-snapshot-21w10a.jpg',
               
                id: 3
        },
              {
                url: 'https://www.pockettactics.com/wp-content/uploads/2020/07/minecraft-houses-1.jpg',
               
                id: 4
        }
              
              
              ]



              const styles = StyleSheet.create({
text1:{
  color:'#D4035E',
  alignItem:'top',
  fontSize:20,
  justifyContent:'top',
  marginBottom:0,
 marginLeft:10,
 marginRight:0

},
buttons: {
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderRadius: 15,
    margin: 10,
    width: 200,
    height: 50,
  },
  imageIcon: {
    width: 260,
    height: 240,
    marginLeft: 55,
  }
})


