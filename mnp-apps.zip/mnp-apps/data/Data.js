import React from 'react';
import {View, Text,TouchableOpacity,StyleSheet} from 'react-native';


export const dummyData =

        [{

                 url: 'https://upload.wikimedia.org/wikipedia/en/a/a5/Grand_Theft_Auto_V.png',
                
                id: 1,
              

        },
        {
                 url: 'https://cdn.mos.cms.futurecdn.net/iSybeeHJC96izazJfb6PpA-1200-80.jpg',
               
                id: 2
        },
        {
                url: 'https://staticg.sportskeeda.com/editor/2020/11/8bd94-16043206673322-800.jpg',
               
                id: 3
        },
              {
                url: 'https://www.gtaboom.com/wp-content/uploads/2020/07/dlc.jpg',
               
                id: 4
        }
              
              
              ]



              const styles = StyleSheet.create({
text1:{
  color:'#D4035E',
  alignItem:'top',
  fontSize:20,
  justifyContent:'top',
  marginBottom:0,
 marginLeft:10,
 marginRight:0

},
buttons: {
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderRadius: 15,
    margin: 10,
    width: 200,
    height: 50,
  },
  imageIcon: {
    width: 260,
    height: 240,
    marginLeft: 55,
  }
})


