import React from 'react';
import {Text,View,StyleSheet,Image,TouchableOpacity} from 'react-native';
import { Linking } from 'react-native';
import Carousel from './components/Carousel'

import { dummyData } from './data/Data'
import { dummyData1 } from './data/Data1'



export default class Games extends React.Component{
  render(){
    return(
      <View style={{flex:1,
      justifyContent:'center',
      alignItem: 'center',
      backgroundColor:'black'}}>

 
<TouchableOpacity onPress={()=>{
  
 Linking.openURL('https://www.gta5-mods.com/tools/gta-v-launcher')
}}>
       
   
<Text style={styles.text1}>
ɖơῳŋƖơąɖ ɧɛཞɛ  ⏭</Text>
       

 
        
     </TouchableOpacity> 
         <Carousel data = {dummyData}/>

  <TouchableOpacity onPress={()=>{

 Linking.openURL('https://tlauncher.org/en/')
}}>
        <Text style={styles.text2}>りのW刀ﾚのﾑり ん乇尺乇  ⏭</Text>
        </TouchableOpacity>
  <Carousel data = {dummyData1}/>

      </View>
    )
  }
}
const styles = StyleSheet.create({
text1:{
  color:'#D4035E',
  alignItem:'top',
  fontSize:20,
  justifyContent:'top',
  marginBottom:0,
 marginLeft:10,
 marginRight:0

},
text2:{
  color:'#E17D09',
  alignItem:'top',
  fontSize:20,
  justifyContent:'top',
  marginBottom:0,
 marginLeft:10,
 marginRight:0

},

})

