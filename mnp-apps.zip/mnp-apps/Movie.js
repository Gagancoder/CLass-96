import React from 'react';
import {Text,View,StyleSheet,Image,TouchableOpacity} from 'react-native';
import { Linking } from 'react-native';
import Carousel from './components/Carousel'

import { dummyData2 } from './data/Data2'
import { dummyData3 } from './data/Data3'



export default class Games extends React.Component{
  render(){
    return(
      <View style={{flex:1,
      justifyContent:'center',
      alignItem: 'center',
      backgroundColor:'black'}}>

    

<TouchableOpacity onPress={()=>{
  
 Linking.openURL('https://www.google.com/search?q=Best+Mrvl+movies&safe=active&hl=en&biw=1536&bih=763&sxsrf=ALeKk03ijEvXp6-DozIR4Q8TJdf3uMOb8Q%3A1623059219426&ei=E-u9YJXHGauR4-EP56ikWA&oq=Best+Mrvl+movies&gs_lcp=Cgdnd3Mtd2l6EAMyBAgAEA0yBAgAEA0yBAgAEA0yBAgAEA0yBAgAEA0yBAgAEA0yBAgAEA0yBAgAEA0yBAgAEA0yBAgAEA06BwgjEOoCECc6BAgjECc6BAgAEEM6BQgAEJECOggIABCxAxCDAToKCC4QxwEQowIQQzoNCC4QsQMQxwEQowIQQzoFCAAQsQM6AggAOgcIABCHAhAUOggIABCxAxDJAzoHCAAQsQMQCjoECAAQCjoKCAAQsQMQgwEQCjoGCAAQFhAeOgUIIRCgAVCuC1jJUGCaVWgCcAJ4AIAB0wKIAfslkgEGMi0xNC40mAEAoAEBqgEHZ3dzLXdperABCsABAQ&sclient=gws-wiz&ved=0ahUKEwjVnOThnoXxAhWryDgGHWcUCQsQ4dUDCA4&uact=5#wxpd=:true')
}}>
       

<Text style={styles.text1}>ᴹᵃʳᵛᵉˡ ᴹᵒᵛⁱᵉˢ ⏭</Text>
 
        
     </TouchableOpacity>
            <Carousel data = {dummyData2}/>

  <TouchableOpacity onPress={()=>{

 Linking.openURL('https://www.google.com/search?q=Best+DC+movies&safe=active&hl=en&biw=1536&bih=763&sxsrf=ALeKk02uXvIwN--0luQV98Etmhl_uvCF5g%3A1623060169975&ei=ye69YJbxOrK94-EP5-if8Ag&oq=Best+DC+movies&gs_lcp=Cgdnd3Mtd2l6EAMyCAgAELEDEJECMgYIABAHEB4yBggAEAcQHjIGCAAQBxAeMgIIADIGCAAQBxAeMgYIABAHEB4yBggAEAcQHjIGCAAQBxAeMgYIABAHEB46BwgjELADECc6BwgAEEcQsANQk_4cWKOAHWCqhB1oAHABeACAAcEDiAGRCZIBBzItMy4wLjGYAQCgAQGqAQdnd3Mtd2l6yAEIwAEB&sclient=gws-wiz&ved=0ahUKEwjW-YSnooXxAhWy3jgGHWf0B44Q4dUDCA4&uact=5#wxpd=:true')
}}>
      

     
  <Text style={styles.text2}>
▓█►─═  đＣ м𝔬שᶤ𝔼Ⓢ ⏭ ═─◄█</Text> 
           



        </TouchableOpacity>
 <Carousel data = {dummyData3}/>
      </View>
    )
  }
}
const styles = StyleSheet.create({
text1:{
  color:'#D4035E',
  alignItem:'top',
  fontSize:20,
  justifyContent:'top',
  marginBottom:0,
 marginLeft:10,
 marginRight:0

},
text2:{
  color:'#E17D09',
  alignItem:'top',
  fontSize:20,
  justifyContent:'top',
  marginBottom:0,
 marginLeft:10,
 marginRight:0

},

})

