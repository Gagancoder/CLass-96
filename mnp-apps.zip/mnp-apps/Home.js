import React from 'react';
import {Text,View,StyleSheet,Image,TouchableOpacity} from 'react-native';
import { Linking } from 'react-native';
import Carousel from './components/Carousel'
import { dummyData } from './data/Data'
export default class Home extends React.Component{
  
  render(){
    return(
      <View style={{flex:1,
      justifyContent:'center',
      alignItem: 'center',
      backgroundColor:'black'
       
}}>
<TouchableOpacity onPress={()=>{
 Linking.openURL('https://www.amazon.in/Kurtzy-Designer-Creative-Stickers-Analogue/dp/B08B8F63VF/ref=sr_1_13?dchild=1&keywords=room+decoration+coding+wathes&qid=1622976563&sr=8-13')
}}>
         <Image
          style={styles.imageIcon}
          source={{
            uri:
              'https://mnpthesolution.com/assets/img/logo.png',
          }}
        /> 
     </TouchableOpacity>


         <View>
 <Text style={styles.text1}>
This app is for Movies,News and playing Games Here you can have a lot of fun Please enjoy this app and do good. 
 </Text>
  <Text style={styles.text2}>
All of the main credits of this app goes to Mr Gagan . 
 </Text>
 <Text style={styles.text3}>
Our Ambacidor is Mr Narender Thakran urf Daddy he gave me all reuqirements what ever i want from him,                  Special Thanks to Daddy
 </Text>
 
</View>
      </View>
   
         
       
    )
  }
} 
const styles = StyleSheet.create({

text1:{
  color:'#D4035E',
  alignItem:'center',
  fontSize:20,
  justifyContent:'center',
marignTop:0,
 marginLeft:30,
 marginRight:30
  
},
text2:{
  color:'orange',
  alignItem:'center',
  fontSize:15,
  justifyContent:'center',
marignTop:0,
 marginLeft:30,
 marginRight:30
  
},
text3:{
  color:'#0081C2',
  alignItem:'center',
  fontSize:10,
  justifyContent:'center',
marignTop:0,
 marginLeft:30,
 marginRight:30
  
},
  imageIcon: {
    width: 250,
    height: 100,
    marginLeft: 55,
    marginBottom:50
  }
})